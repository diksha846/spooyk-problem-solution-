const route = require('express').Router()
const Order = require("./Order");

route.get('/getAllOrders', async(req, res) => {
    try {
        const result = await Order.find({}).exec();
        res.status(200).json(result);
    } catch (exec) {
        res.status(400).json(exec.error);
    }
});


//To be updated
route.post('/updateOrder', (req, res) => {
    const {
        ItemId,
        Price,
        CustomerId,
        DeliveryVehicleId,
        IsDelivered
    } = req.body;
    const { authorization } = req.headers;
    res.send({
        ItemId,
        Price,
        CustomerId,
        DeliveryVehicleId,
        IsDelivered
    });
});

module.exports = route;