const route = require('express').Router();
const Item = require('./Item');


route.post('/items', async(req, res, next) => {
    try {
        console.log(req.body);
        if (!req.body.Name || !req.body.Price) {
            res.status(400).json('Missing params');
        }
        const newItem = new Item(req.body);
        await newItem.save();
        res.status(200).json(req.body);
    } catch (exec) {
        res.status(exec.code).json(exec.error);
    }
});

route.get('/items', async(req, res, next) => {
    try {
        const result = await Item.find({}).exec();
        res.status(200).json(result);
    } catch (exec) {
        res.status(400).json(exec.error);
    }
});

module.exports = route;