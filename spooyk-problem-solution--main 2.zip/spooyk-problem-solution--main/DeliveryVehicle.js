const mongoose = require('mongoose');
const name = 'DeliveryVehicle';

const schema = new mongoose.Schema({

    RegistrationNumber: {
        type: String,
        required: true,
        unique: true,
    },
    VehicleType: {
        type: String,
        enum: ['Bike', 'Truck'],
        required: true
    },
    City: {
        type: String,
    },
    ActiveOrdersCount: {
        type: Number,
        default: 0,
        max: 2,
        select: false,
    },
});


const model = mongoose.model(name, schema);

module.exports = model;