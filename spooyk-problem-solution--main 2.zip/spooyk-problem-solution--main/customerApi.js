// Importing express module
//const express = require('express');
//const app = express();

const Customer = require('./Customer');

const route = require('express').Router()
    //app.use(express.json());


route.get('/customers', async(req, res) => {
    try {
        const result = await Customer.find({}).exec();
        res.status(200).json(result);
    } catch (exec) {
        res.status(400).json(exec.error);
    }
});

route.post('/customers', async(req, res) => {
    try {
        if (!req.body.Name || !req.body.City) {
            res.status(400).json('Missing params');
        }
        const newCustomer = new Customer(req.body);
        await newCustomer.save();
        res.status(200).json(req.body);
    } catch (exec) {
        res.status(exec.code).json(exec.error);
    }
});

module.exports = route;