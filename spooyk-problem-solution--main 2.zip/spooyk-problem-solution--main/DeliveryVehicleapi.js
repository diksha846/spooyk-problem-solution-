//
const DeliveryVehicle = require('./DeliveryVehicle');
const route = require('express').Router();


route.get('/deliveryVehicle', async(req, res) => {
    try {
        const result = await DeliveryVehicle.find({}).exec();
        res.status(200).json(result);
    } catch (exec) {
        res.status(400).json(exec.error);
    }
});

route.post('/deliveryVehicle', async(req, res) => {
    try {
        const {
            RegistrationNumber,
            VehicleType,
            City,
        } = req.body;

        if (!req.body.RegistrationNumber || !req.body.VehicleType || !req.body.City) {
            res.status(400).json('Missing params');
        }
        const newDeliveryItem = new DeliveryVehicle(req.body);
        await newDeliveryItem.save();
        res.status(200).json(res.body);
    } catch (exec) {
        res.status(exec.code).json(exec.error);
    }
});

module.exports = route;