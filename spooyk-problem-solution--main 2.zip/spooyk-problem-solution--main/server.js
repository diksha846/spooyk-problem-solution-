const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');
const req = require('express/lib/request');
require('dotenv').config({ silent: true });
// Setup App
const app = express();
const port = 3001;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use("/", require("./customerApi"));
app.use("/", require("./DeliveryVehicleapi"));
app.use("/", require("./orderApi"));
app.use("/", require("./itemApi"));

app.use(cors());
app.use(
    bodyParser.urlencoded({
        extended: true,
        limit: '50mb',
    })
);

app.use(
    bodyParser.json({
        limit: '50mb',
    })
);

//Connect To Database
mongoose.Promise = global.Promise;
mongoose.connect("mongodb://127.0.0.1:27017/mydb").then(
    () => {
        //require('./models')();
        //require('./routes')(app);
        require("./Customer");
        require("./DeliveryVehicle");
        require("./Item");
        require("./Order");

        app.listen(port, () => {
            console.log(`App running at http://localhost:${port}`);
        });
    },
    (err) => {
        console.error('Error in connecting db.', err);
    }
);


/* */