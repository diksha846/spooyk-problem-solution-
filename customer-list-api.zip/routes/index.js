module.exports = (app) => {
	require('./itemRoutes')(app);
};
